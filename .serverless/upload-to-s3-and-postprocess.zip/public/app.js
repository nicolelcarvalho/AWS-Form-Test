$(document).ready(function() {

// alert("hello!");
// var fileName = $("#image").val("name");
// console.log(fileName);


});